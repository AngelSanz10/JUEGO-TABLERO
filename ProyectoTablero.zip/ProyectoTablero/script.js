"use strict";
function inicio() {
    // Variables principales del proyecto
    let botonDado = document.getElementById("boton-dado"); // Botón para lanzar el dado
    let mensajeRecords = document.getElementById("mensajeRecord"); // Mensaje que muestra el récord actual
    let elementosTablero = document.getElementById("tablero"); // Tabla que representa el tablero del juego
    let botonInicio = document.getElementById("boton-inicio"); // Botón para iniciar el juego
    let botonReiniciar = document.getElementById("reiniciar"); // Botón para reiniciar el juego
    let inputNombre = document.getElementById("nombre-usuario"); // Input para ingresar el nombre del usuario
    let dadoImagen = document.getElementById("dado-imagen"); // Imagen del dado

    // Constantes
    const tablero = []; // Representa el tablero como una matriz bidimensional
    const recordTiradas = "recordTiradas"; // Clave para almacenar el récord en localStorage
    const heroeImg = "IMG/link.png"; // Imagen del héroe
    const cofreImg = "IMG/zelda.png"; // Imagen del cofre

    // Variables del juego
    let nombreUsuario = ""; // Nombre del usuario
    let posicionHeroe = { fila: 0, columna: 0 }; // Posición inicial del héroe
    let posicionCofre = { fila: 9, columna: 9 }; // Posición fija del cofre
    let numeroTiradas = 0; // Contador de tiradas realizadas

    // Configuración inicial: ocultar elementos
    botonDado.style.display = "none";
    mensajeRecords.style.display = "none";
    botonReiniciar.style.display = "none";

    // Función para validar el nombre del usuario
    function validarNombre() {
        nombreUsuario = inputNombre.value.trim(); // Elimina espacios adicionales
        const mensajeValidacion = document.getElementById("mensaje-validacion");

        // Validación del nombre ingresado
        if (nombreUsuario.length < 4) {
            mensajeValidacion.textContent = "El nombre debe tener 4 o más letras.";
            botonInicio.disabled = true;
        } else if (!isNaN(nombreUsuario)) {
            mensajeValidacion.textContent = "Números no permitidos.";
            botonInicio.disabled = true;
        } else {
            mensajeValidacion.textContent = "Nombre correcto.";
            botonInicio.disabled = false;
        }
    }

    // Función para inicializar el tablero
    function inicializarTablero() {
        elementosTablero.innerHTML = ""; // Limpia el contenido previo del tablero
        tablero.length = 0; // Resetea la matriz del tablero

        // Genera una tabla 10x10
        for (let i = 0; i < 10; i++) {
            const fila = [];
            const filaElem = document.createElement("tr"); // Fila de la tabla

            for (let j = 0; j < 10; j++) {
                const celda = document.createElement("td"); // Celda de la tabla
                fila.push(celda); // Agrega la celda a la fila
                filaElem.appendChild(celda); // Agrega la celda al DOM
            }

            tablero.push(fila); // Agrega la fila al tablero
            elementosTablero.appendChild(filaElem); // Agrega la fila al DOM
        }

        inputNombre.disabled = true; // Bloquea el input tras iniciar el juego
        actualizarTablero(); // Actualiza la visualización inicial
    }

    // Función para actualizar la visualización del tablero
    function actualizarTablero() {
        for (let i = 0; i < 10; i++) {
            for (let j = 0; j < 10; j++) {
                const celda = tablero[i][j];
                celda.onclick = null; // Elimina eventos previos
                celda.style.backgroundColor = ""; // Limpia el color de fondo
                celda.style.backgroundImage = ""; // Limpia la imagen previa

                // Agrega la imagen del héroe o del cofre según la posición
                if (i === posicionHeroe.fila && j === posicionHeroe.columna) {
                    celda.style.backgroundImage = `url(${heroeImg})`;
                } else if (i === posicionCofre.fila && j === posicionCofre.columna) {
                    celda.style.backgroundImage = `url(${cofreImg})`;
                }
            }
        }
    }

    // Función para marcar movimientos válidos en el tablero según el dado
    function marcarMovimientosValidos(dado) {
        // Limpia las marcas previas
        for (let i = 0; i < 10; i++) {
            for (let j = 0; j < 10; j++) {
                let celda = tablero[i][j];
                celda.onclick = null;
                celda.style.backgroundColor = "";
            }
        }

        // Marca las celdas válidas
        function marcarCelda(i, j) {
            if (i >= 0 && i < 10 && j >= 0 && j < 10) {
                tablero[i][j].onclick = () => moverHeroe(i, j); // Agrega el evento de clic
                tablero[i][j].style.backgroundColor = "red"; // Destaca la celda
            }
        }

        // Marca las celdas válidas en las cuatro direcciones
        for (let i = 1; i <= dado; i++) {
            marcarCelda(posicionHeroe.fila - i, posicionHeroe.columna); // Arriba
            marcarCelda(posicionHeroe.fila + i, posicionHeroe.columna); // Abajo
            marcarCelda(posicionHeroe.fila, posicionHeroe.columna - i); // Izquierda
            marcarCelda(posicionHeroe.fila, posicionHeroe.columna + i); // Derecha
        }
    }

    // Función para mover al héroe
    function moverHeroe(fila, columna) {
        posicionHeroe = { fila, columna }; // Actualiza la posición del héroe
        numeroTiradas++; // Incrementa el contador de tiradas
        actualizarTablero(); // Refresca el tablero

        // Comprueba si el héroe alcanzó el cofre
        if (fila === posicionCofre.fila && columna === posicionCofre.columna) {
            verificarRecord(); // Verifica si hay un nuevo récord
            alert(`¡Ganaste, ${nombreUsuario}! Lo lograste en ${numeroTiradas} tiradas.`);
            botonDado.disabled = true; // Desactiva el dado
            botonReiniciar.style.display = "inline-block"; // Muestra el botón de reinicio
        } else {
            botonDado.disabled = false; // Habilita el dado
        }
    }

    // Función para tirar el dado
    function tirarDado() {
        const dado = Math.floor(Math.random() * 6) + 1; // Genera un número aleatorio entre 1 y 6
        dadoImagen.src = `IMG/dado${dado}.png`; // Actualiza la imagen del dado
        dadoImagen.style.display = "block"; // Muestra la imagen del dado
        botonDado.disabled = true; // Desactiva el botón del dado hasta que se mueva el héroe
        marcarMovimientosValidos(dado); // Marca los movimientos válidos
    }

    // Función para verificar y registrar récords
    function verificarRecord() {
        const recordActual = parseInt(localStorage.getItem(recordTiradas)) || Infinity; // Obtiene el récord guardado
        if (numeroTiradas < recordActual) {
            localStorage.setItem(recordTiradas, numeroTiradas); // Guarda el nuevo récord
            mensajeRecords.textContent = `¡Nuevo récord! Récord actual: ${numeroTiradas} tiradas.`;
        } else {
            mensajeRecords.textContent = `Récord actual: ${recordActual} tiradas.`;
        }
    }

    // Función para reiniciar el juego
    function reiniciarJuego() {
        numeroTiradas = 0; // Resetea el contador de tiradas
        posicionHeroe = { fila: 0, columna: 0 }; // Restaura la posición inicial del héroe
        botonReiniciar.style.display = "none"; // Oculta el botón de reinicio
        inicializarTablero(); // Inicializa el tablero
        botonDado.disabled = false; // Habilita el botón del dado
        dadoImagen.style.display = "none"; // Oculta la imagen del dado
    }

    // Eventos principales
    botonInicio.onclick = () => {
        numeroTiradas = 0;
        posicionHeroe = { fila: 0, columna: 0 }; // Restaura la posición inicial del héroe
        inicializarTablero(); // Inicializa el tablero
        botonDado.disabled = false; // Habilita el botón del dado
        botonInicio.style.display = "none"; // Oculta el botón de inicio
        mensajeRecords.style.display = "block"; // Muestra el mensaje del récord
        botonDado.style.display = "inline-block"; // Muestra el botón del dado
        dadoImagen.style.display = "none"; // Oculta la imagen del dado
    };

    botonDado.onclick = tirarDado; // Asocia el evento de tirar el dado
    botonReiniciar.onclick = reiniciarJuego; // Asocia el evento de reiniciar el juego
    inputNombre.oninput = validarNombre; // Valida el nombre en tiempo real

    // Mostrar récord inicial
    verificarRecord();
}

// Llamada a la función inicial
inicio();
